import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';

import { BaseComponent } from './base.component';

import { DerivedComponent } from './derived.component';
import { DerivedComponentOne } from './derivedOne.component';

@NgModule({
  declarations: [
    AppComponent, BaseComponent, DerivedComponent , DerivedComponentOne ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
