import { Component } from '@angular/core';
import { BaseComponent } from './base.component';

@Component({
  selector : 'my-inherited1',
  template: `
  <div style='background-color: pink'>
     {{val}}hello
  </div>
`
})
export class DerivedComponentOne extends BaseComponent {}