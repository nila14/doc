import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';


import { EmployeeComponent } from './employee.component';
import { PipePipe } from './pipe.pipe';
@NgModule({
  declarations: [
    AppComponent
,EmployeeComponent, PipePipe   ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
