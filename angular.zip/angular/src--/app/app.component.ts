import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
isValid = false;
ids = [1,2,3,4];
title = 'app';

	users = [
      new User('Mahesh', 20),
      new User('Krishna', 22),
      new User('Narendra', 31)
    ];
 }

export class User {
  constructor(public name: string, public age: number) { 
  }
}