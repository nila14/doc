package com.cts.mentor.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.cts.mentor.entity.Training;

public interface TrainingRepository extends CrudRepository<Training,Long> {

	List<Training> getCompletedTraining();

	List<Training> getUnderProgressTrainings();

	List<Training> getApprovedTrainings();

	List<Training> getProposedTrainings();

}
