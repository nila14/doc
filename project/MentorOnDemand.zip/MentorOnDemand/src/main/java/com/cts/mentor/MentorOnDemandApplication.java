package com.cts.mentor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MentorOnDemandApplication {

	public static void main(String[] args) {
		SpringApplication.run(MentorOnDemandApplication.class, args);
	}

}
